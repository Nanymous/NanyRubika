class copyright:
	__Version__ = "2.7.5"
	print("")
	CopyRight = print(f"""✵ 𝙲𝚘𝚙𝚢𝚛𝚒𝚐𝚑𝚝 (𝙲) 𝙽𝚊𝚗𝚢𝚖𝚘𝚞𝚜

✵ 𝙻𝚒𝚋𝚛𝚊𝚛𝚢 𝚅𝚎𝚛𝚜𝚎𝚗𝚒𝚘𝚜 : {__Version__}

✵ 𝚁𝚞𝚋𝚒𝚔𝚊 𝙸𝙳 : @𝙽𝚊𝚗𝚢𝚖𝚘𝚞𝚜

𝙶𝚒𝚝𝚑𝚞𝚋 ⭛

https://github.com/Nanymous/NanyRubika""")
	print(".......................................")
	print(" ")
