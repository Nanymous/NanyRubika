class clien:
    web = {
        "app_name": "Main",
        "app_version": "4.2.0",
        "platform": "Web",
        "package": "web.rubika.ir",
        "lang_code": "fa"
    }

    android = {
        "app_name": "Main",
        "app_version": "3.0.9",
        "platform": "Android",
        "package": "app.rbmain.a",
        "lang_code": "fa"
    }
		